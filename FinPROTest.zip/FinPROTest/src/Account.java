public class Account {
    private String username;
    private String password;
    private double balance;
    private double expense;


    public Account(String username, String password) {
        this.username = username;
        this.password = password;
        this.balance = 0;
        this.expense = 0;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }
    public double getExpense() {
        return expense;
    }
    public double getBalance(){
        return balance;
    }
}
